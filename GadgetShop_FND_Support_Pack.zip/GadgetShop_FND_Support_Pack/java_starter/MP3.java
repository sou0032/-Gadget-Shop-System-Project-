/**
 * MP3.java
 * Subclass of Gadget with available memory.
 */
public class MP3 extends Gadget {
    private int availableMemory;

    public MP3(String model, double price, int weight, String size, int availableMemory) {
        super(model, price, weight, size);
        this.availableMemory = availableMemory;
    }

    public int getAvailableMemory() { return availableMemory; }

    public void downloadMusic(int memoryNeeded) {
        if (memoryNeeded <= 0) {
            System.out.println("Download size must be positive.");
        } else if (availableMemory >= memoryNeeded) {
            availableMemory = availableMemory - memoryNeeded;
            System.out.println("Music downloaded. Remaining memory: " + availableMemory + "MB");
        } else {
            System.out.println("Insufficient memory to download this music.");
        }
    }

    public void deleteMusic(int memoryFreed) {
        if (memoryFreed > 0) {
            availableMemory = availableMemory + memoryFreed;
            System.out.println("Music deleted. Available memory: " + availableMemory + "MB");
        } else {
            System.out.println("Deleted music size must be positive.");
        }
    }

    public void display() {
        super.display();
        System.out.println("Available memory: " + availableMemory + "MB");
    }
}
