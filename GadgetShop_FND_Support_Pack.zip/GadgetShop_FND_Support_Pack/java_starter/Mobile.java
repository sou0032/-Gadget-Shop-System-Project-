/**
 * Mobile.java
 * Subclass of Gadget. You should understand and be able to explain every line.
 */
public class Mobile extends Gadget {
    private int callingCredit;

    public Mobile(String model, double price, int weight, String size, int callingCredit) {
        super(model, price, weight, size);
        this.callingCredit = callingCredit;
    }

    public int getCallingCredit() { return callingCredit; }

    public void addCredit(int credit) {
        if (credit > 0) {
            callingCredit = callingCredit + credit;
            System.out.println(credit + " minutes added. Remaining credit: " + callingCredit);
        } else {
            System.out.println("Please enter a positive amount of calling credit.");
        }
    }

    public void makeCall(String phoneNumber, int duration) {
        if (duration <= 0) {
            System.out.println("Call duration must be positive.");
        } else if (callingCredit >= duration) {
            System.out.println("Calling " + phoneNumber + " for " + duration + " minutes.");
            callingCredit = callingCredit - duration;
            System.out.println("Remaining credit: " + callingCredit);
        } else {
            System.out.println("Insufficient credit to make this call.");
        }
    }

    public void display() {
        super.display();
        System.out.println("Calling credit: " + callingCredit + " minutes");
    }
}
