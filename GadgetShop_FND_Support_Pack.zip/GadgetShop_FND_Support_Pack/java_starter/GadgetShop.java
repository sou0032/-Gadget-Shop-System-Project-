import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.*;

/**
 * GadgetShop.java
 * Guided starter GUI. It follows the assignment structure and uses sample product data
 * inspired by your pasted Samsung S25 Ultra and MP3/DAP comparison notes.
 */
public class GadgetShop extends JFrame implements ActionListener {
    private ArrayList<Gadget> gadgets = new ArrayList<Gadget>();

    private JTextField modelField = new JTextField(18);
    private JTextField priceField = new JTextField(8);
    private JTextField weightField = new JTextField(8);
    private JTextField sizeField = new JTextField(18);
    private JTextField creditField = new JTextField(8);
    private JTextField memoryField = new JTextField(8);
    private JTextField phoneField = new JTextField(12);
    private JTextField durationField = new JTextField(8);
    private JTextField downloadField = new JTextField(8);
    private JTextField displayNumberField = new JTextField(8);

    public GadgetShop() {
        setTitle("Sharon's Gadget Shop");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel inputPanel = new JPanel(new GridLayout(10, 2, 5, 5));
        inputPanel.setBorder(BorderFactory.createTitledBorder("Gadget Details"));
        inputPanel.add(new JLabel("Model")); inputPanel.add(modelField);
        inputPanel.add(new JLabel("Price (£)")); inputPanel.add(priceField);
        inputPanel.add(new JLabel("Weight (g)")); inputPanel.add(weightField);
        inputPanel.add(new JLabel("Size")); inputPanel.add(sizeField);
        inputPanel.add(new JLabel("Initial credit")); inputPanel.add(creditField);
        inputPanel.add(new JLabel("Initial memory (MB)")); inputPanel.add(memoryField);
        inputPanel.add(new JLabel("Phone number")); inputPanel.add(phoneField);
        inputPanel.add(new JLabel("Duration")); inputPanel.add(durationField);
        inputPanel.add(new JLabel("Download size (MB)")); inputPanel.add(downloadField);
        inputPanel.add(new JLabel("Display number")); inputPanel.add(displayNumberField);

        JPanel buttonPanel = new JPanel(new GridLayout(2, 3, 5, 5));
        String[] names = {"Add Mobile", "Add MP3", "Clear", "Display All", "Make A Call", "Download Music"};
        for (String name : names) {
            JButton button = new JButton(name);
            button.addActionListener(this);
            buttonPanel.add(button);
        }

        add(inputPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private String getModel() { return modelField.getText(); }
    private String getSizeText() { return sizeField.getText(); }
    private String getPhoneNumber() { return phoneField.getText(); }
    private double getPrice() { return Double.parseDouble(priceField.getText()); }
    private int getWeight() { return Integer.parseInt(weightField.getText()); }
    private int getCredit() { return Integer.parseInt(creditField.getText()); }
    private int getMemory() { return Integer.parseInt(memoryField.getText()); }
    private int getDuration() { return Integer.parseInt(durationField.getText()); }
    private int getDownloadSize() { return Integer.parseInt(downloadField.getText()); }

    private int getDisplayNumber() {
        int displayNumber = -1;
        try {
            int number = Integer.parseInt(displayNumberField.getText());
            if (number >= 0 && number < gadgets.size()) {
                displayNumber = number;
            } else {
                JOptionPane.showMessageDialog(this, "Display number must be between 0 and " + (gadgets.size() - 1));
            }
        } catch (NumberFormatException exception) {
            JOptionPane.showMessageDialog(this, "Display number must be a whole number.");
        }
        return displayNumber;
    }

    public void actionPerformed(ActionEvent event) {
        String command = event.getActionCommand();
        try {
            if (command.equals("Add Mobile")) {
                gadgets.add(new Mobile(getModel(), getPrice(), getWeight(), getSizeText(), getCredit()));
                JOptionPane.showMessageDialog(this, "Mobile added at display number " + (gadgets.size() - 1));
            } else if (command.equals("Add MP3")) {
                gadgets.add(new MP3(getModel(), getPrice(), getWeight(), getSizeText(), getMemory()));
                JOptionPane.showMessageDialog(this, "MP3 added at display number " + (gadgets.size() - 1));
            } else if (command.equals("Clear")) {
                clearFields();
            } else if (command.equals("Display All")) {
                for (int i = 0; i < gadgets.size(); i++) {
                    System.out.println("Display number: " + i);
                    gadgets.get(i).display();
                    System.out.println();
                }
            } else if (command.equals("Make A Call")) {
                int index = getDisplayNumber();
                if (index != -1) {
                    Mobile mobile = (Mobile) gadgets.get(index);
                    mobile.makeCall(getPhoneNumber(), getDuration());
                }
            } else if (command.equals("Download Music")) {
                int index = getDisplayNumber();
                if (index != -1) {
                    MP3 mp3 = (MP3) gadgets.get(index);
                    mp3.downloadMusic(getDownloadSize());
                }
            }
        } catch (NumberFormatException exception) {
            JOptionPane.showMessageDialog(this, "Please enter valid numbers in the numeric fields.");
        } catch (ClassCastException exception) {
            JOptionPane.showMessageDialog(this, "The selected gadget is the wrong type for this action.");
        }
    }

    private void clearFields() {
        modelField.setText(""); priceField.setText(""); weightField.setText(""); sizeField.setText("");
        creditField.setText(""); memoryField.setText(""); phoneField.setText(""); durationField.setText("");
        downloadField.setText(""); displayNumberField.setText("");
    }

    public static void main(String[] args) {
        new GadgetShop();
    }
}
